import szam
import korok


szam.szam()
korok.korok()
